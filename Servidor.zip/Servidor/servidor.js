const express = require('express');
const path = require('path');
var http = require('http');
var app = express();
const { MongoClient, ServerApiVersion, ObjectId } = require('mongodb'); 
// --- importante: npm install express ejs mongodb path// ---mongodb+srv://fernandadosscosta_db_user:<db_password>@fullstack.ojvxp0y.mongodb.net/
// --- Configuração de Porta ---
const PORT = 3000; 

// --- Middleware & Config ---
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// ⚠️ CORREÇÃO DE CAMINHO PARA VIEWS (volta um nível '..')
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));

// ⚠️ CORREÇÃO DE CAMINHO PARA PUBLIC (volta um nível '..')
app.use(express.static(path.join(__dirname, '..', 'public')));


// --- Configuração e Conexão com MongoDB ---
const uri = "mongodb+srv://fernandadosscosta_db_user:NoDKpWMmDiheOZNE@fullstack.ojvxp0y.mongodb.net/?appName=Fullstack";
const client = new MongoClient(uri, {
    serverApi: {
        version: ServerApiVersion.v1,
        strict: true,
        deprecationErrors: true,
    }
});

let db; 

async function connectDB() {
    try {
        await client.connect();
        db = client.db("fullstack"); 
        console.log("Conectado ao MongoDB!");
    } catch (e) {
        console.error("Erro ao conectar ao MongoDB:", e);
        process.exit(1); 
    }
}


// ======================
// ===== ROTAS WEB (CRUD BÁSICO) =====
// ======================

app.get('/', (req, res) => {
    res.redirect('/Project.html');
});

// ... (Outras rotas de login/cadastro aqui) ...

// ROTA DE POST CORRIGIDA PARA SALVAR NO MONGODB
app.post('/blog', async (req, res) => {
    const { titulo, resumo, conteudo } = req.body; 

    if (!db) {
        return res.status(500).send("Erro: Conexão com o banco de dados não estabelecida.");
    }
    
    const newPost = {
        titulo: titulo,
        resumo: resumo,
        conteudo: conteudo,
        data: new Date()
    };
    
    try {
        const collection = db.collection('posts'); 
        await collection.insertOne(newPost);
        
        res.render('res_blog', { titulo, resumo, conteudo, mensagem: "Postagem salva no MongoDB com sucesso!" });
        
    } catch (error) {
        console.error("Erro ao salvar o post:", error);
        res.status(500).send("Erro ao salvar a postagem no banco de dados.");
    }
});


// ======================
// ===== INICIALIZAÇÃO DO SERVIDOR =====
// ======================

var server = http.createServer(app);

connectDB().then(() => {
    server.listen(PORT, () => {
        const message = `Servidor rodando em http://localhost:${PORT}`;
        try {
            require('colors'); 
            console.log(message.rainbow);
        } catch (e) {
            console.log(message);
        }
    });
});